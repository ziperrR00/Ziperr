module.exports = {
  BOT_TOKEN: "7706055606:AAFi2jLFVlJb1NroBo_LVygL2M8Bvo5ScNs",
    allowedDevelopers: ['7013997051'], // ID
}; 